str1='hello world'
str2=' '
print(type(str1))
print(type(str2))