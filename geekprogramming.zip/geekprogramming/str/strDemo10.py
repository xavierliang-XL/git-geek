list=['www','amazon','com']
print('.'.join(list))