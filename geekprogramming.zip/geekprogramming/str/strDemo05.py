str='D A V I D'
print(str.replace(' ','',100))