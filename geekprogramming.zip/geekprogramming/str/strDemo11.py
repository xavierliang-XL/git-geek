str='hello world hello python'
print(str.startswith('hello',5,8))
