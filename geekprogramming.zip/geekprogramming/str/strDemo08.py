str='hello world and hello python'
print(str.split('and'))