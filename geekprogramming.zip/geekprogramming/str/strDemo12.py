str='111hello'
print(str.isalpha())

print(str.isdigit())

print(str.isalnum())

