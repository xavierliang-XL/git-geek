str1='byte'
str2='tube'
str3='by'
str4='dal'
print(str1.join(str2))