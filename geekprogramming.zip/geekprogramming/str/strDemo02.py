username=input('plz enter ur username')
password=input('plz enter ur password')
saved_username=username
saved_password=password
print(username,password)