list=[1,2,3,4]
list.append('a')
print(list)
list2=['byte','tube']
list2.extend('dal')
print(list2)

list3=[10,20,30]
list.insert(2,100)
print(list)
list.remove(2,100)
print(list)
