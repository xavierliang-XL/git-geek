list=[1,2,3,4,5]
for i in range(len(list)):
    print(list[i])