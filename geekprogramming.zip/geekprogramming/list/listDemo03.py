name_list=['david','xavier','alan','jim']
name_list.insert(1,'dal')
print(name_list)