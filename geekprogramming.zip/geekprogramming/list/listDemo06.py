name_list=['david','xavier','alan','jim']
print(name_list)
#copy():复制
copied_list=name_list.copy()
print(copied_list)