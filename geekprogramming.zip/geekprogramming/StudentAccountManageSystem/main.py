from geekprogramming.StudentAccountManageSystem.managementSystem import managementSystem

if __name__=='__main__':
    student_system = managementSystem()
    student_system.run()