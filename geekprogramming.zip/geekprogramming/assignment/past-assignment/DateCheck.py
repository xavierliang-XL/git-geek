uI=int(input('plz enter your date:'))
result='monday' if uI==1 else 'tuesday' if uI==2 else 'wednesday' if uI==3 else 'thursday' if uI==4 else 'friday' if uI==5 else 'saturday' if uI==6 else 'sunday' if uI==7 else 'invalid input'
print(result)