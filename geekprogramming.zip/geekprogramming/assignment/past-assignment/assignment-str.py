name="Tom"
age=18
number=1
weight=75.6
print(f"我的学号是{number}")
print(f"我的体重是{weight}")
print(f"我的名字是{name},今年{age}岁了")