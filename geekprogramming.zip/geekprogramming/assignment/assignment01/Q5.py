num1=1
num2=1
print(num1,end=' ')
while(num2<50):
    print(num2, end=' ')
    res=num1
    num1=num2
    num2=num2+res