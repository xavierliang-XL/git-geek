i=1
while(i<5):
    for j in range(1,i+1):
        print('*',end='  ')
    print()
    i+=1
while(i!=0):
    for j in range(1,i+1):
        print('*',end='  ')
    print()
    i-=1