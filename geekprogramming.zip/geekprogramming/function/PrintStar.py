def printStar(m,n):
    for i in range(m):
        for j in range(n):
            print('*',end="  ")
        print()
printStar(5,5)