num_set={1,2,3,4}
num_set2=set(num_set)
print(num_set)
print(num_set2)