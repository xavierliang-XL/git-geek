class Dog(object):
    tooth=10
    def __init__(self):
        self.age=5

    @staticmethod
    def info_print():
        a=100
        return a
    