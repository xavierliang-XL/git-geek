print(2)

def info_print2():
    print('module2')