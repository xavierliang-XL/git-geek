print(1)

def info_print1():
    print('module1')