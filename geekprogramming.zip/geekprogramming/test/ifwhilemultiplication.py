num=1
while num<=9:
    for i in range(1,num+1):
        print(f"{num}*{i}={num*i}", end=" ")
    print()
    num+=1