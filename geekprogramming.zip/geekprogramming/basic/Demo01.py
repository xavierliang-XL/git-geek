'''
num=10
print(type(num))
print(num)


my_name='Tom'
print(my_name)

school_name='bytetube'
print(school_name)
'''

uI=input('plz input date:')
if (eval(uI))==False:
    print('invalid')
else:
   if uI==1:
       print(uI)


