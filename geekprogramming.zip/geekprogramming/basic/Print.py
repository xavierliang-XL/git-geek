age=18
name='Tom'
weight=75.5
student_id=1

print("我的名字是%s"%name)

print("我的学号是%4d"% student_id)

print('我的体重是%.2f公斤'% weight)

print('我的名字是%s，今年%d岁了'%(name,age))

print('我的名字是%s，明年%d岁了'%(name,age+1))