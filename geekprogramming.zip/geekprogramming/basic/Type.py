a=1
print(type(a))

b=1.1
print(type(b))

c = True
print(type(c))

d = '12345'
print(type(d))

e = [10, 20, 30]
print(type(a))

f = (10, 20, 30)
print(type(f))

h = {10, 20, 30}
print(type(h))

g={'name': 'Tom', 'age': 20}
print(type(g))

