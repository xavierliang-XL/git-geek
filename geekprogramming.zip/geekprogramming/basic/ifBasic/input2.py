num1=eval(input("please enter your first num:"))
num2=eval(input("please enter your second num:"))
if num1>num2:
    print(f"the min value is {num2}")
else:
    print(f"the min value is {num1}")


password=input('plz enter your passward')

print(f'password is {password}')

print(type(password))