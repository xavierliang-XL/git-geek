age=int(input("plz enter your age"))
if age<=16:
    print('illegal')
elif age>16 and age<=60:
    print('legal')
else:
    print('retire')

print('over')
