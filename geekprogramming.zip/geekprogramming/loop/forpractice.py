integer=100
res=0
while integer>=1:
    if integer%2==0:
        res+=integer
    integer-=1

print(res)

