for a in range(4,8):
    for b in range(4,8):
        for c in range(4,8):
            if a!=b and a!=c and c!=b:
                print(a,b,c)
