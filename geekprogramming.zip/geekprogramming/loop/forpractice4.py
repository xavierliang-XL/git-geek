str='bytetube'
for i in str:
    print(i)

