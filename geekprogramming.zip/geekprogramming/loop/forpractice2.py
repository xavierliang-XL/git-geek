num=0
while num<5:
    num2=0
    while num2<=num:
        print('*',end='  ')
        num2+=1
    print()
    num+=1