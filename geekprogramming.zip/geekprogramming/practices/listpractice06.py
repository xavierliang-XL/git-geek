list=[1,1,2,3,4,4,5]
def getEle(list):
    list2=set(list)
    return list2
print(getEle(list))