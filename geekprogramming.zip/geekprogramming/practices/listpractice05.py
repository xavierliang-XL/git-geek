
dict={"a":10,"b":20,"c":30}
def sum_values(dict):
    return sum(dict.values())
print(sum_values(dict))