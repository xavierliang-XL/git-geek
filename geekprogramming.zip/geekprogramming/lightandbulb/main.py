from geekprogramming.lightandbulb.StashManagementSystem import management

if __name__=='__main__':
    system = management()
    system.run()